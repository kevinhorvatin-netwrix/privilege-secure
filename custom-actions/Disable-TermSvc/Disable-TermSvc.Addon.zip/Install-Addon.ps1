$dbToolsDir = Join-Path $Env:ProgramFiles -ChildPath "Stealthbits/PAM/DatabaseTools"
$regKey = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Netwrix\Netwrix Privilege Secure' -ErrorAction SilentlyContinue
if ($null -eq $regKey) {
    $regKey = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Stealthbits Technologies\Stealthbits Privileged Activity Manager' -ErrorAction SilentlyContinue
}

if ($null -ne $regKey) {
    $dbToolsDir = Join-Path $regKey.InstallDirectory -ChildPath "DatabaseTools" -ErrorAction SilentlyContinue
}

$actionSvcDir = Join-Path $Env:ProgramFiles -ChildPath "Stealthbits/PAM/ActionServiceWorker"
$regKey = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Netwrix\Netwrix Privilege Secure Action Service' -ErrorAction SilentlyContinue
if ($null -eq $regKey) {
    $regKey = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Stealthbits Technologies\Stealthbits Privileged Activity Manager Action Service' -ErrorAction SilentlyContinue
}

if ($null -ne $regKey) {
    $actionSvcDir = Join-Path $regKey.InstallDirectory -ChildPath "ActionService" -ErrorAction SilentlyContinue
}

Write-Host "Found DatabaseTools directory: $dbToolsDir"
Write-Host "Found ActionService directory: $actionSvcDir"

$Ans = Read-Host "Install addon? Y|N"
if ("Y" -ne $Ans) {
    Write-Host "Not installing addon..."
    return
}
$DbUpdater = Join-Path $dbToolsDir -ChildPath SbPAM.DbUpdater.exe
if (-not (Test-Path $DbUpdater))
{
    Write-Error "Stopping install`nUnable to find SbPAM.DbUpdater: $DbUpdater!"
    return
}
$DevTemplates = $PSScriptRoot
if (Test-Path "$DevTemplates/ActionTemplates")
{
    &$DbUpdater import $DevTemplates
}
else {
    Write-Error "Stopping install`nUnable to find addon definition directory: $DevTemplates/ActionTemplates!"
    return
}

if (Test-Path "$DevTemplates/Scripts")
{
    Push-Location $DevTemplates
    $AddonPath = (Join-Path $actionSvcDir -ChildPath "Addon")
    if (-not (Test-Path $AddonPath))
    {
        New-Item -ItemType Directory -Path $AddonPath | Out-Null
    }

    Get-ChildItem -Path Scripts -Filter *.ps*1 | Copy-Item -Destination $AddonPath -Verbose

    Pop-Location
}
